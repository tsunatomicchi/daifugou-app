import type { FC } from 'react';
export interface CustomOverlayProps { initialOpen?: boolean; }
export declare const CustomOverlay: FC<CustomOverlayProps>;
export default CustomOverlay;
